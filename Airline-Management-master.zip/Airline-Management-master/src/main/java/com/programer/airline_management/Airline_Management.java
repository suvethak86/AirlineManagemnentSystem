/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.programer.airline_management;

/**
 *
 * @author ROG
 */
public class Airline_Management {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
